"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// import DynamoDB from "aws-sdk/clients/dynamodb";
const dynamodb_1 = require("aws-sdk/clients/dynamodb");
const dynamoDBClient = () => {
    if (process.env.IS_OFFLINE) {
        return new dynamodb_1.DocumentClient({
            region: "localhost",
            endpoint: "http://localhost:5000",
        });
    }
    return new dynamodb_1.DocumentClient();
};
exports.default = dynamoDBClient;
